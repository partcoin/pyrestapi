class requestdata:
	'''Represents any Request data.'''
	# Construct the request.
	def __init__(self, url, httpMethod="GET", data=None, params= None, mimeType = "application/json", cookieMap=None, remoteIP=None, isTimeout=False, timeout=None):
		self.url = url
		self.mimeType = mimeType
		self.data = data
		self.params = params
		self.httpMethod = httpMethod
		self.cookieMap = cookieMap
		self.remoteIP = remoteIP
		self.isTimeout = isTimeout
		# The timeout value will be applied to both the connect and the read timeouts.
		# Specify a tuple if you would like to set the values separately.
		if (isTimeout == False):
		    self.timeout = timeout
		else:
			self.timeout = (9, 27)