
import json
import os
import requests
import constants
import restservice
import requestdata
import unittest, time
import xmlrunner
import re
from paramiko import SSHClient, AutoAddPolicy

service = restservice.restservice()


class message_tests():

    def getServiceTest(self ,url ,httpMethod ,dict):

        # Build the request data.
        req_data = requestdata.requestdata(url, httpMethod ,cookieMap=dict)

        # Call the REST Service and receive the response.

        res = service.execute(req_data)
        print(res.status_code);

        # Process the response

        if (res.status_code == requests.codes.ok):
            if (res.headers['content-type'] == "application/json"):
                print("Service returned: ", json.dumps(res.json()))
            else :
                print("content type" ,res.headers['content-type'])
                print("Service returned: ", res.text)

        elif (res.status_code == requests.codes.not_found):
            print ("The requested resource is not found.")
        elif (res.status_code == requests.codes.bad_request):
            print ("Bad Request.")
        else:
            print("Please check for the response code.")
            print("The status code is: ", res.status_code)
        return(res.status_code)


# TEST : SERVICE INSTANCE REST API - LIST ALL SERVICES for TARGET ACTIVATION/DEACTIVATION
class ListServiceInstanceTest(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['SERVICE_INSTANCES']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


# TEST : HEALTHCHECK SERVICE API
class HealthCheckTest(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['HEALTHCHECK_SERVICE']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


# TEST : SERVICE ACTIVATION of LCS12C target using API  :
# Input :test.json & valid service_instance_id "5"

class ServiceActivation(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        path = os.path.join(os.path.dirname(__file__), 'test.json')
        url = constants.BASE_URL + '/' + constants.REST_API_POST['SERVICE_ACTIVATION']
        with open(path) as json_file:
            json_data = json.load(json_file)
        headers = {'Content-Type': 'application/json'}
        requests.packages.urllib3.disable_warnings()
        print("The data:", json.dumps(json_data))
        r = requests.post(url, data=json.dumps(json_data), headers=headers, verify=False, cookies=dict)
        # Process the response.
        self.assertEqual(r.status_code,200);
        if (r.status_code == requests.codes.ok):
            if (r.headers['content-type'] == "application/json"):
                print("Service returned: ", json.dumps(r.json()))


# TEST : SERVICE DEACTIVATION of LCS12C target using API  :
# Input :test.json & valid service_instance_id "5"

class ServiceDeActivation(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        path = os.path.join(os.path.dirname(__file__), 'test.json')
        url = constants.BASE_URL + '/' + constants.REST_API_POST['SERVICE_DEACTIVATION']
        with open(path) as json_file:
            json_data = json.load(json_file)
        headers = {'Content-Type': 'application/json'}
        requests.packages.urllib3.disable_warnings()
        r = requests.post(url, data=json.dumps(json_data), headers=headers, verify=False, cookies=dict)
        # Process the response.
        self.assertEqual(r.status_code, 200);
        if (r.status_code == requests.codes.ok):
            if (r.headers['content-type'] == "application/json"):
                print("Service returned: ", json.dumps(r.json()))


# TEST : EM12ASR STATUS API

class EM12ASRTest(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['EM12ASR_STATUS']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


# TEST : SERVICE METRICS API

class ServiceMetricsTest(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['SERVICE_METERICS']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


# TEST : GW PROXY SETTINGS TEST REST API

class GWProxyTest(unittest.TestCase):
    def setUp(self):
        pass
    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['GW_PROXY']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


# TEST : GET PATCHES  TEST REST API

class GetPatchTest(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['GET_PATCHES']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


# TEST : GET ALL OEM AGENTS installed on the Gateway TEST REST API

class GetAllOEMAgents(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['GET_OEM_AGENTS']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


# TEST : GET REMOTE STATUS GREENBUTTON on GW

class FetchRemoteStatus(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['REMOTE_STATUS']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


# TEST : REMOTE DISABLE GREEN TOGGLE OFF ON GW

class RemoteDisable(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['REMOTE_DISABLE']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


# TEST : REMOTE ENABLE GREEN TOGGLE OFF ON GW

class RemoteEnable(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['REMOTE_ENABLE']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


class DataCollectors(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['HEALTHCHECK_DATACOLLECTOR']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


class DataCollectorsSave(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        path = os.path.join(os.path.dirname(__file__), 'datacollectorssave.json')
        url = constants.BASE_URL + '/' + constants.REST_API_GET['HEALTHCHECK_DATACOLLECTOR']
        with open(path) as json_file:
            json_data = json.load(json_file)
        headers = {'Content-Type': 'application/json'}
        requests.packages.urllib3.disable_warnings()
        r = requests.post(url, data=json.dumps(json_data), headers=headers, verify=False, cookies=dict)
        # Process the response.
        self.assertEqual(r.status_code, 200)
        if (r.status_code == requests.codes.ok):
            if (r.headers['content-type'] == "application/json"):
                global dcId
                dcId = json.dumps(r.json())
                print("Service returned: ", json.dumps(r.json()))


class DataCollectorsUpdate(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        data = re.search(r'"id": "(\w+)"', dcId)

        path = os.path.join(os.path.dirname(__file__), 'datacollectorsupdate.json')
        url = constants.BASE_URL + '/' + constants.REST_API_GET['HEALTHCHECK_DATACOLLECTOR'] + '/' + data.group(1)
        with open(path, 'r+') as json_file:
            json_data = json.load(json_file)
            json_data['id'] = data.group(1)
            json_file.seek(0)
            json_file.write(json.dumps(json_data))
            json_file.truncate()
        headers = {'Content-Type': 'application/json'}
        requests.packages.urllib3.disable_warnings()
        r = requests.put(url, data=json.dumps(json_data), headers=headers, verify=False, cookies=dict)
        # Process the response.
        self.assertEqual(r.status_code, 200)


class DataCollectorsDelete(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        data = re.search(r'"id": "(\w+)"', dcId)
        httpMethod = "DELETE"
        url = constants.BASE_URL + '/' + constants.REST_API_GET[
            'HEALTHCHECK_DATACOLLECTOR'] + '/' + data.group(1)
        req_data = requestdata.requestdata(url, httpMethod, cookieMap=dict)
        r = service.execute(req_data)
        # Process the response.
        self.assertEqual(r.status_code, 204)


class HealthChecks(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['HEALTHCHECK']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)


class HealthCheckSave(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        data = re.search(r'"id": "(\w+)"', dcId)
        path = os.path.join(os.path.dirname(__file__), 'healthchecksave.json')
        url = constants.BASE_URL + '/' + constants.REST_API_GET['HEALTHCHECK']
        with open(path, 'r+') as json_file:
            json_data = json.load(json_file)
            json_data['dataCollectorId'] = data.group(1)
            json_file.seek(0)
            json_file.write(json.dumps(json_data))
            json_file.truncate()
        headers = {'Content-Type': 'application/json'}
        requests.packages.urllib3.disable_warnings()
        r = requests.post(url, data=json.dumps(json_data), headers=headers, verify=False, cookies=dict)
        # Process the response.
        self.assertEqual(r.status_code, 200)
        if (r.status_code == requests.codes.ok):
            if (r.headers['content-type'] == "application/json"):
                global newId
                newId = json.dumps(r.json())
                print("Service returned: ", json.dumps(r.json()))


class HealthCheckUpdate(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        hcId = re.search(r'"id": "(\w+)"', newId)
        dc = re.search(r'"id": "(\w+)"', dcId)
        path = os.path.join(os.path.dirname(__file__), 'healthcheckupdate.json')
        url = constants.BASE_URL + '/' + constants.REST_API_GET['HEALTHCHECK'] + '/' + hcId.group(1)
        with open(path, 'r+') as json_file:
            json_data = json.load(json_file)
            json_data['id'] = hcId.group(1)
            json_data['dataCollectorId'] = dc.group(1)
            json_file.seek(0)
            json_file.write(json.dumps(json_data))
            json_file.truncate()
        headers = {'Content-Type': 'application/json'}
        requests.packages.urllib3.disable_warnings()
        r = requests.put(url, data=json.dumps(json_data), headers=headers, verify=False, cookies=dict)
        # Process the response.
        self.assertEqual(r.status_code, 200)


class HealthCheckDelete(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        data = re.search(r'"id": "(\w+)"', newId)
        httpMethod = "DELETE"
        url = constants.BASE_URL + '/' + constants.REST_API_GET[
            'HEALTHCHECK'] + '/' + data.group(1)
        req_data = requestdata.requestdata(url, httpMethod, cookieMap=dict)
        r = service.execute(req_data)
        # Process the response.
        self.assertEqual(r.status_code, 204)


class HealthCheckGroup(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['HEALTHCHECK_GROUP']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)

class HealthCheckGroupSave(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        data = re.search(r'"name": "(\w+)"', newId)
        path = os.path.join(os.path.dirname(__file__), 'healthcheckgroupsave.json')
        url = constants.BASE_URL + '/' + constants.REST_API_GET['HEALTHCHECK_GROUP']
        with open(path,'r+') as json_file:
            json_data = json.load(json_file)
            json_data['healthchecks'] = [data.group(1)]
            json_file.seek(0)
            json_file.write(json.dumps(json_data))
            json_file.truncate()
        headers = {'Content-Type': 'application/json'}
        requests.packages.urllib3.disable_warnings()
        r = requests.post(url, data=json.dumps(json_data), headers=headers, verify=False, cookies=dict)
        # Process the response.
        self.assertEqual(r.status_code, 200)
        if (r.status_code == requests.codes.ok):
            if (r.headers['content-type'] == "application/json"):
                global hcgId
                hcgId = json.dumps(r.json())
                print("Service returned: ", json.dumps(r.json()))

class HealthCheckGroupUpdate(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        data = re.search(r'"id": "(\w+)"', hcgId)
        hc = re.search(r'"name": "(\w+)"', newId)
        path = os.path.join(os.path.dirname(__file__), 'healthcheckgroupupdate.json')
        url = constants.BASE_URL + '/' + constants.REST_API_GET['HEALTHCHECK_GROUP'] + '/' + data.group(1)
        with open(path,'r+') as json_file:
            json_data = json.load(json_file)
            json_data['id'] = data.group(1)
            json_data['healthchecks'] = [hc.group(1)]
            json_file.seek(0)
            json_file.write(json.dumps(json_data))
            json_file.truncate()
        headers = {'Content-Type': 'application/json'}
        requests.packages.urllib3.disable_warnings()
        r = requests.put(url, data=json.dumps(json_data), headers=headers, verify=False, cookies=dict)
        # Process the response.
        self.assertEqual(r.status_code, 200)

class HealthCheckGroupDelete(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        data = re.search(r'"id": "(\w+)"', hcgId)
        httpMethod = "DELETE"
        url = constants.BASE_URL + '/' + constants.REST_API_GET[
            'HEALTHCHECK_GROUP'] + '/' + data.group(1)
        req_data = requestdata.requestdata(url, httpMethod, cookieMap=dict)
        r = service.execute(req_data)
        # Process the response.
        self.assertEqual(r.status_code, 204)

class ExternalConnectivity(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['CONNECTIVITY_EXTERNAL']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)

class HealthCheckSummary(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        msg = message_tests()
        url = constants.BASE_URL + '/' + constants.REST_API_GET['HEALTHCHECK_SUMMARY']
        httpMethod = "GET"
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)
        
class HealthCheckOutput(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        data = re.search(r'"id": "(\w+)"', newId)
        httpMethod = "GET"
        url = constants.BASE_URL + '/' + constants.REST_API_GET[
            'HEALTHCHECK'] + '/' + data.group(1) + '/output'
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)

class HealthCheckTarget(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        data = re.search(r'"id": "(\w+)"', newId)
        httpMethod = "GET"
        url = constants.BASE_URL + '/' + constants.REST_API_GET[
            'HEALTHCHECK'] + '/' + data.group(1) + '/targets'
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)

class HealthCheckGroupDataCollectorList(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        data = re.search(r'"id": "(\w+)"', hcgId)
        httpMethod = "GET"
        url = constants.BASE_URL + '/' + constants.REST_API_GET[
            'HEALTHCHECK_GROUP'] + '/dataCollectors/' + data.group(1)
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)
 
class HealthCheckGroupHealthCheckList(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        data = re.search(r'"id": "(\w+)"', hcgId)
        httpMethod = "GET"
        url = constants.BASE_URL + '/' + constants.REST_API_GET[
            'HEALTHCHECK_GROUP'] + '/' + data.group(1) + '/healthchecks'
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)

class NotificationTemplate(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        httpMethod = "GET"
        url = constants.BASE_URL + '/' + constants.REST_API_GET[
            'NOTIFICATION_TEMPLATE']
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)
     
class NotificationRoles(unittest.TestCase):
    def setUp(self):
        pass

    def runTest(self):
        httpMethod = "GET"
        url = constants.BASE_URL + '/' + constants.REST_API_GET[
            'NOTIFICATION_ROLES']
        retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
        self.assertEqual(retCode, 200)  
        
# Main Program
if __name__ == '__main__':

    # Fetch the Cookies Session ID Dynamically using USER_LOGIN/IS_USER_LOGIN REST API's

    url = constants.BASE_URL + '/' + constants.REST_API_POST['USER_LOGIN']
    s = requests.Session()
    requests.packages.urllib3.disable_warnings()
    # Use setup_user_form_data below for setup user test execution
    # Use customer_user_form_date below for customer user test execution
    s.post(url, verify=False, data=constants.setup_user_form_data)
    oasgid = s.cookies.get('OASG_SESSION_ID')
    url = constants.BASE_URL + '/' + constants.REST_API_GET['IS_USER_LOGIN']
    s = requests.Session()
    requests.packages.urllib3.disable_warnings()
    s.post(url, verify=False)
    jsid = s.cookies.get('JSESSIONID')
    dict = {}
    dict.update({'OASG_SESSION_ID': oasgid})
    dict.update({'JSESSIONID': jsid})
    # MAIN TEST : IS User Login true on GW Portal using Cookie based authentication ? -> Yes proceed with further tests
    msg = message_tests()
    httpMethod = "GET"
    retCode = msg.getServiceTest(url=url, httpMethod=httpMethod, dict=dict)
    if (retCode == 200):
        print("User login to GW Portal Success,return code is:", retCode)
		
		# Get version
        # ssh client
        ssh_client = SSHClient()
        ssh_client.set_missing_host_key_policy(AutoAddPolicy())
        ssh_client.load_system_host_keys()
        ssh_client.connect(hostname = constants.HOST, username=constants.setup_user_form_data['userid'], password = constants.setup_user_form_data['password'])

        # run a command
        print ("\nRun command")
        cmd = 'sudo rpm -qa | grep -i oasg-meta | cut -f3 -d\'-\''
        stdin, stdout, stderr = ssh_client.exec_command(cmd)
        output = re.search(r'(\d+)\.\d+\.\d+', stdout.read().rstrip().decode())
        version = int(output.group(1))
        ssh_client.close()
 
        if (version >= 8): 
            smoketestsuite = unittest.TestSuite()
            smoketestsuite.addTest(unittest.makeSuite(FetchRemoteStatus))
            smoketestsuite.addTest(unittest.makeSuite(RemoteDisable))
            smoketestsuite.addTest(unittest.makeSuite(ListServiceInstanceTest))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckTest))
            smoketestsuite.addTest(unittest.makeSuite(ServiceActivation))
            smoketestsuite.addTest(unittest.makeSuite(ServiceDeActivation))
            smoketestsuite.addTest(unittest.makeSuite(EM12ASRTest))
            smoketestsuite.addTest(unittest.makeSuite(GWProxyTest))
            smoketestsuite.addTest(unittest.makeSuite(GetPatchTest))
            smoketestsuite.addTest(unittest.makeSuite(GetAllOEMAgents))
            smoketestsuite.addTest(unittest.makeSuite(FetchRemoteStatus))
            smoketestsuite.addTest(unittest.makeSuite(RemoteEnable))
            smoketestsuite.addTest(unittest.makeSuite(DataCollectors))
            smoketestsuite.addTest(unittest.makeSuite(DataCollectorsSave))
            smoketestsuite.addTest(unittest.makeSuite(DataCollectorsUpdate))
            smoketestsuite.addTest(unittest.makeSuite(HealthChecks))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckSave))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckUpdate))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckGroup))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckGroupSave))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckGroupUpdate))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckOutput))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckTarget))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckGroupDataCollectorList))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckGroupHealthCheckList))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckGroupDelete))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckDelete))
            smoketestsuite.addTest(unittest.makeSuite(DataCollectorsDelete))
            smoketestsuite.addTest(unittest.makeSuite(ExternalConnectivity))
            smoketestsuite.addTest(unittest.makeSuite(HealthCheckSummary))
            smoketestsuite.addTest(unittest.makeSuite(NotificationTemplate))
            smoketestsuite.addTest(unittest.makeSuite(NotificationRoles))
            
            # XML Based Runner to capture the report stored in directory python_tests_xml

            runner = xmlrunner.XMLTestRunner('python_tests_xml')
            runner.run(smoketestsuite)


        else:
            print ("Version < 8.0")        
    else:
        print("Unable to user login to GW Portal return code is", retCode)








