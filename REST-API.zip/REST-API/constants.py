import sys

PORT = 8443
HOST = sys.argv[1]
BASE_URL = "https://" + HOST + ":" + str(PORT)



REST_API_GET = {'IS_USER_LOGIN': "rest/userservice/is_user_login",
                'HEALTHCHECK_SERVICE': "rest/connectivities/targets?hostName=10.80.189.197&targetType=cell-node",
                'SERVICE_INSTANCES': "rest/service/instances",
                'EM12ASR_STATUS': "rest/acsservice/em12asr/status",
                'SERVICE_METERICS': "rest/acsservice/servicemetrics",
                'GW_PROXY':  "rest/gateway/settings/proxy",
                'GET_PATCHES': "rest/patches",
                'GET_OEM_AGENTS': "rest/oem/agents",
                'MQS_PROD': "https://meteringinternal.oraclecloud.com:9999/metering/api/v1/usage",
                'PTB_ACT': "rest/activation/templates/wizard/ptbs_activation_options.tmpl.html?7.0.261",
                'REMOTE_ENABLE': "rest/remoteAccess/enable",
                'REMOTE_STATUS': "rest/remoteAccess/status",
                'REMOTE_DISABLE': "rest/remoteAccess/disable",
				'HEALTHCHECK_DATACOLLECTOR': "rest/datacollectors",
                'HEALTHCHECK': "rest/healthchecks",
                'HEALTHCHECK_GROUP': "rest/healthCheckGroups",
                'CONNECTIVITY_EXTERNAL': "rest/connectivities/externals",
                'HEALTHCHECK_SUMMARY':  "rest/healthchecks/summaries",
                'NOTIFICATION_TEMPLATE': "rest/notifications/templates/healthCheck",
                'NOTIFICATION_ROLES': "rest/notifications/roles",
                'LIST_SERVICE': "rest/service/instances/122/removable/9B159237449B67795F1E1C0A68266164"
                }




REST_API_POST={'SERVICE_ACTIVATION': "rest/service/instances/5",
               'SERVICE_DEACTIVATION': "rest/service/instances/deactivation/5",
               'CORRELATION_ID': "rest/service/status/1472535506879",
               'USER_LOGIN': "rest/userservice/user_login"

               }


setup_user_form_data = {
        'userid': 'setup'
        , 'password': '1Cat2Fish!'
            }

customer_user_form_data = {
        'userid': 'mk'
        , 'password': '2Cat2Fish!'
            }
