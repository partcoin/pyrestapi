import requests

# Global response variable.
res = ""

class restservice:

	'''The Rest Service.'''
	def __init__(self):
		pass

	def execute(self, requestdata):
		'''Execute the rest query.'''

		print ( "Executing:", requestdata.url)

		if (requestdata.httpMethod == "GET"):
			requests.packages.urllib3.disable_warnings()

			res = requests.get(requestdata.url, params = requestdata.params, timeout = requestdata.timeout, verify=False,cookies=requestdata.cookieMap)
		elif (requestdata.httpMethod == "POST"):
			requests.packages.urllib3.disable_warnings()
			# 'json' attribute would automatically encode the data.
			print("The data:", requestdata.data)
			res = requests.post(requestdata.url, json = requestdata.data, timeout = requestdata.timeout, verify=False,cookies=requestdata.cookieMap)
		elif (requestdata.httpMethod == "PUT"):
			requests.packages.urllib3.disable_warnings()
			res = requests.put(requestdata.url, json = requestdata.data, timeout = requestdata.timeout, verify=False,cookies=requestdata.cookieMap)
		elif (requestdata.httpMethod == "DELETE"):
			requests.packages.urllib3.disable_warnings()
			res = requests.delete(requestdata.url, params = requestdata.params, timeout = requestdata.timeout, verify=False,cookies=requestdata.cookieMap)
		elif (requestdata.httpMethod == "HEAD"):
			# Please provide the implementation
			pass
		elif (requestdata.httpMethod == "PATCH"):
			# Please provide the implementation
			pass
		else:
			print("Unsupported REST method.Please check for the request method.")

		return res